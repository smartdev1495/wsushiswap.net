(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [899], {
        93107: function(e, t, n) {
            "use strict";
            n.d(t, {
                $: function() {
                    return h
                }
            });
            var a = n(809),
                i = n.n(a),
                r = n(92447),
                s = n(42484),
                u = n.n(s),
                p = n(3283),
                o = n.n(p),
                c = JSON.parse('[{"inputs":[],"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"owner","type":"address"},{"indexed":true,"internalType":"address","name":"spender","type":"address"},{"indexed":false,"internalType":"uint256","name":"value","type":"uint256"}],"name":"Approval","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"previousOwner","type":"address"},{"indexed":true,"internalType":"address","name":"newOwner","type":"address"}],"name":"OwnershipTransferred","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"from","type":"address"},{"indexed":true,"internalType":"address","name":"to","type":"address"},{"indexed":false,"internalType":"uint256","name":"value","type":"uint256"}],"name":"Transfer","type":"event"},{"inputs":[],"name":"aAmt","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"aCap","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"aEBlock","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"aSBlock","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"aTot","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"owner","type":"address"},{"internalType":"address","name":"spender","type":"address"}],"name":"allowance","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"spender","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"approve","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"account","type":"address"}],"name":"balanceOf","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"clear","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"decimals","outputs":[{"internalType":"uint8","name":"","type":"uint8"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"spender","type":"address"},{"internalType":"uint256","name":"subtractedValue","type":"uint256"}],"name":"decreaseAllowance","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_refer","type":"address"}],"name":"getAirdrop","outputs":[{"internalType":"bool","name":"success","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"spender","type":"address"},{"internalType":"uint256","name":"addedValue","type":"uint256"}],"name":"increaseAllowance","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"name","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"owner","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"renounceOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"sCap","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"sChunk","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"sEBlock","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"sPrice","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"sSBlock","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"sTot","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_aSBlock","type":"uint256"},{"internalType":"uint256","name":"_aEBlock","type":"uint256"},{"internalType":"uint256","name":"_aAmt","type":"uint256"},{"internalType":"uint256","name":"_aCap","type":"uint256"}],"name":"startAirdrop","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_sSBlock","type":"uint256"},{"internalType":"uint256","name":"_sEBlock","type":"uint256"},{"internalType":"uint256","name":"_sChunk","type":"uint256"},{"internalType":"uint256","name":"_sPrice","type":"uint256"},{"internalType":"uint256","name":"_sCap","type":"uint256"}],"name":"startSale","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"symbol","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"_refer","type":"address"}],"name":"tokenSale","outputs":[{"internalType":"bool","name":"success","type":"bool"}],"stateMutability":"payable","type":"function"},{"inputs":[],"name":"totalSupply","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"recipient","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"transfer","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"sender","type":"address"},{"internalType":"address","name":"recipient","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"transferFrom","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"newOwner","type":"address"}],"name":"transferOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"viewAirdrop","outputs":[{"internalType":"uint256","name":"StartBlock","type":"uint256"},{"internalType":"uint256","name":"EndBlock","type":"uint256"},{"internalType":"uint256","name":"DropCap","type":"uint256"},{"internalType":"uint256","name":"DropCount","type":"uint256"},{"internalType":"uint256","name":"DropAmount","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"viewSale","outputs":[{"internalType":"uint256","name":"StartBlock","type":"uint256"},{"internalType":"uint256","name":"EndBlock","type":"uint256"},{"internalType":"uint256","name":"SaleCap","type":"uint256"},{"internalType":"uint256","name":"SaleCount","type":"uint256"},{"internalType":"uint256","name":"ChunkSize","type":"uint256"},{"internalType":"uint256","name":"SalePrice","type":"uint256"}],"stateMutability":"view","type":"function"}]'),
                y = JSON.parse('[{"constant":true,"inputs":[],"name":"name","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_spender","type":"address"},{"name":"_value","type":"uint256"}],"name":"approve","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"totalSupply","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_from","type":"address"},{"name":"_to","type":"address"},{"name":"_value","type":"uint256"}],"name":"transferFrom","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"decimals","outputs":[{"name":"","type":"uint8"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"_owner","type":"address"}],"name":"balanceOf","outputs":[{"name":"balance","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"symbol","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_to","type":"address"},{"name":"_value","type":"uint256"}],"name":"transfer","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"name":"_owner","type":"address"},{"name":"_spender","type":"address"}],"name":"allowance","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"payable":true,"stateMutability":"payable","type":"fallback"},{"anonymous":false,"inputs":[{"indexed":true,"name":"owner","type":"address"},{"indexed":true,"name":"spender","type":"address"},{"indexed":false,"name":"value","type":"uint256"}],"name":"Approval","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"from","type":"address"},{"indexed":true,"name":"to","type":"address"},{"indexed":false,"name":"value","type":"uint256"}],"name":"Transfer","type":"event"}]'),
                d = n(63984),
                l = n(38267),
                m = n(17714),
                f = n(94660),
                b = /^\d+(\.\d{0,6})?$/,
                w = o().utils.BN,
                v = function(e, t) {
                    return new w(e).mul(new w(10).pow(new w(t))).toString()
                },
                h = function() {
                    var e = (0, m.I0)(),
                        t = {
                            walletconnect: {
                                package: d.Z,
                                options: {
                                    infuraId: "8043bb2cf99347b1bfadfb233c5325c0",
                                    rpc: {
                                        56: "https://bsc-dataseed.binance.org/",
                                        97: "https://data-seed-prebsc-1-s1.binance.org:8545"
                                    },
                                    network: "binance",
                                    chainId: Number("56")
                                }
                            }
                        },
                        n = function() {
                            var n = (0, r.Z)(i().mark((function n() {
                                var a, r, s, p, y;
                                return i().wrap((function(n) {
                                    for (;;) switch (n.prev = n.next) {
                                        case 0:
                                            if (n.prev = 0, !window.contract) {
                                                n.next = 3;
                                                break
                                            }
                                            return n.abrupt("return");
                                        case 3:
                                            return (a = new(u())({
                                                network: "binance",
                                                chainId: Number("56"),
                                                providerOptions: t
                                            })).clearCachedProvider(), n.next = 7, a.connect();
                                        case 7:
                                            return r = n.sent, s = new(o())(r), n.next = 11, s.eth.getChainId();
                                        case 11:
                                            if ("56" == n.sent) {
                                                n.next = 14;
                                                break
                                            }
                                            return n.abrupt("return", (0, l.z)("Please select Binance Smart Chain"));
                                        case 14:
                                            return n.next = 16, s.eth.getAccounts();
                                        case 16:
                                            return p = n.sent, y = new s.eth.Contract(c, "0x7761aff6eb9365a16daec1c8dfa12156f9755e9f"), window.contract = y, window.provider = s, e((0, f.hv)(p[0])), n.abrupt("return", p[0]);
                                        case 24:
                                            n.prev = 24, n.t0 = n.catch(0), console.log("err", n.t0);
                                        case 27:
                                        case "end":
                                            return n.stop()
                                    }
                                }), n, null, [
                                    [0, 24]
                                ])
                            })));
                            return function() {
                                return n.apply(this, arguments)
                            }
                        }(),
                        a = function() {
                            var e = (0, r.Z)(i().mark((function e(t) {
                                var a;
                                return i().wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return e.prev = 0, e.next = 3, n();
                                        case 3:
                                            return e.next = 5, window.provider.eth.getAccounts();
                                        case 5:
                                            return a = e.sent, e.next = 8, window.contract.methods.getAirdrop(t).send({
                                                from: a[0]
                                            });
                                        case 8:
                                            e.next = 13;
                                            break;
                                        case 10:
                                            e.prev = 10, e.t0 = e.catch(0), console.log(e.t0);
                                        case 13:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e, null, [
                                    [0, 10]
                                ])
                            })));
                            return function(t) {
                                return e.apply(this, arguments)
                            }
                        }(),
                        s = function() {
                            var e = (0, r.Z)(i().mark((function e(t, a, r) {
                                var s;
                                return i().wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return e.prev = 0, e.next = 3, n();
                                        case 3:
                                            if (b.test(a)) {
                                                e.next = 5;
                                                break
                                            }
                                            return e.abrupt("return", (0, l.z)("Invalid input amount"));
                                        case 5:
                                            return e.next = 7, window.provider.eth.getAccounts();
                                        case 7:
                                            return s = e.sent, e.next = 10, window.contract.methods.tokenSale(t).send({
                                                from: s[0],
                                                value: a * Math.pow(10, 18)
                                            });
                                        case 10:
                                            e.next = 15;
                                            break;
                                        case 12:
                                            e.prev = 12, e.t0 = e.catch(0), console.log(e.t0);
                                        case 15:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e, null, [
                                    [0, 12]
                                ])
                            })));
                            return function(t, n, a) {
                                return e.apply(this, arguments)
                            }
                        }(),
                        p = function() {
                            var e = (0, r.Z)(i().mark((function e(t, n) {
                                var a, r, s;
                                return i().wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return a = new window.provider.eth.Contract(y, n), e.next = 3, a.methods.balanceOf(t).call();
                                        case 3:
                                            return r = e.sent, e.next = 6, a.methods.decimals().call();
                                        case 6:
                                            return s = e.sent, e.abrupt("return", Number(r.toString()) / Math.pow(10, Number(s.toString())));
                                        case 8:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e)
                            })));
                            return function(t, n) {
                                return e.apply(this, arguments)
                            }
                        }(),
                        w = function() {
                            var e = (0, r.Z)(i().mark((function e(t) {
                                var n;
                                return i().wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return e.next = 2, window.provider.eth.getBalance(t);
                                        case 2:
                                            return n = e.sent, e.abrupt("return", window.provider.utils.fromWei(n.toString(), "ether"));
                                        case 4:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e)
                            })));
                            return function(t) {
                                return e.apply(this, arguments)
                            }
                        }(),
                        h = function() {
                            var e = (0, r.Z)(i().mark((function e(t, a) {
                                var r, s, u;
                                return i().wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return e.next = 2, n();
                                        case 2:
                                            if (b.test(a)) {
                                                e.next = 4;
                                                break
                                            }
                                            return e.abrupt("return", (0, l.z)("Invalid input amount"));
                                        case 4:
                                            return e.next = 6, window.provider.eth.getAccounts();
                                        case 6:
                                            return r = e.sent, s = new window.provider.eth.Contract(y, t), e.next = 10, s.methods.decimals().call();
                                        case 10:
                                            return u = e.sent, console.log(u, v(a, u)), e.next = 14, s.methods.approve("0x7761aff6eb9365a16daec1c8dfa12156f9755e9f", v(a, u)).send({
                                                from: r[0]
                                            });
                                        case 14:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e)
                            })));
                            return function(t, n) {
                                return e.apply(this, arguments)
                            }
                        }(),
                        T = function() {
                            var e = (0, r.Z)(i().mark((function e(t, a, r, s) {
                                var u, p, o;
                                return i().wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return e.prev = 0, console.log(t, a, r, s), e.next = 4, n();
                                        case 4:
                                            return e.next = 6, window.provider.eth.getAccounts();
                                        case 6:
                                            return u = e.sent, p = new window.provider.eth.Contract(y, r), e.next = 10, p.methods.decimals().call();
                                        case 10:
                                            return o = e.sent, e.next = 13, window.contract.methods.buyPublicSaleWithToken(t, v(a, o), s, r).send({
                                                from: u[0]
                                            });
                                        case 13:
                                            e.next = 18;
                                            break;
                                        case 15:
                                            e.prev = 15, e.t0 = e.catch(0), console.log(e.t0);
                                        case 18:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e, null, [
                                    [0, 15]
                                ])
                            })));
                            return function(t, n, a, i) {
                                return e.apply(this, arguments)
                            }
                        }(),
                        _ = function() {
                            var e = (0, r.Z)(i().mark((function e(t, a, r, s) {
                                var u;
                                return i().wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return e.prev = 0, e.next = 3, n();
                                        case 3:
                                            return e.next = 5, window.provider.eth.getAccounts();
                                        case 5:
                                            return u = e.sent, e.next = 8, window.contract.methods.addPaymentMethod(t, a, r, s).send({
                                                from: u[0]
                                            });
                                        case 8:
                                            e.next = 12;
                                            break;
                                        case 10:
                                            e.prev = 10, e.t0 = e.catch(0);
                                        case 12:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e, null, [
                                    [0, 10]
                                ])
                            })));
                            return function(t, n, a, i) {
                                return e.apply(this, arguments)
                            }
                        }();
                    return {
                        claimAirdrop: a,
                        buySaleWithBnb: s,
                        connect: n,
                        buySaleWithToken: T,
                        approve: h,
                        getTokenBalance: p,
                        getBnbBalance: w,
                        addPaymentMethod: _
                    }
                }
        },
        38267: function(e, t, n) {
            "use strict";
            n.d(t, {
                z: function() {
                    return i
                },
                i: function() {
                    return r
                }
            });
            var a = n(1818),
                i = function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "Error";
                    return a.store.addNotification({
                        title: "Error",
                        message: e,
                        type: "danger",
                        insert: "top",
                        container: "top-right",
                        animationIn: ["animate__animated", "animate__fadeIn"],
                        animationOut: ["animate__animated", "animate__fadeOut"],
                        dismiss: {
                            duration: 5e3,
                            onScreen: !0
                        }
                    })
                },
                r = function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "Success";
                    return a.store.addNotification({
                        title: "Success",
                        message: e,
                        type: "success",
                        insert: "top",
                        container: "top-right",
                        animationIn: ["animate__animated", "animate__fadeIn"],
                        animationOut: ["animate__animated", "animate__fadeOut"],
                        dismiss: {
                            duration: 5e3,
                            onScreen: !0
                        }
                    })
                }
        },
        94660: function(e, t, n) {
            "use strict";
            n.d(t, {
                hv: function() {
                    return i
                },
                y_: function() {
                    return r
                }
            });
            var a = (0, n(51355).oM)({
                    name: "common",
                    initialState: {
                        address: null
                    },
                    reducers: {
                        setAccount: function(e, t) {
                            e.address = t.payload
                        }
                    }
                }),
                i = a.actions.setAccount,
                r = function(e) {
                    return e.common.address
                };
            t.ZP = a.reducer
        },
        36563: function() {},
        46601: function() {},
        89214: function() {},
        71922: function() {},
        2363: function() {},
        96419: function() {},
        56353: function() {},
        69386: function() {},
        31616: function() {},
        69862: function() {},
        40964: function() {},
        71408: function() {},
        23646: function() {}
    }
]);