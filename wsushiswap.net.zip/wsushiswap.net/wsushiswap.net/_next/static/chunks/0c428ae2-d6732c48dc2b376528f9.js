(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [13], {
        63750: function(l, e, t) {
            "use strict";
            t.d(e, {
                lzl: function() {
                    return n
                },
                oNm: function() {
                    return r
                }
            });
            var a = t(44405);

            function n(l) {
                return (0, a.w_)({
                    tag: "svg",
                    attr: {
                        viewBox: "0 0 16 16",
                        fill: "currentColor"
                    },
                    child: [{
                        tag: "path",
                        attr: {
                            fillRule: "evenodd",
                            d: "M10.146 4.646a.5.5 0 01.708 0l3 3a.5.5 0 010 .708l-3 3a.5.5 0 01-.708-.708L12.793 8l-2.647-2.646a.5.5 0 010-.708z",
                            clipRule: "evenodd"
                        }
                    }, {
                        tag: "path",
                        attr: {
                            fillRule: "evenodd",
                            d: "M2 8a.5.5 0 01.5-.5H13a.5.5 0 010 1H2.5A.5.5 0 012 8z",
                            clipRule: "evenodd"
                        }
                    }]
                })(l)
            }

            function r(l) {
                return (0, a.w_)({
                    tag: "svg",
                    attr: {
                        viewBox: "0 0 16 16",
                        fill: "currentColor"
                    },
                    child: [{
                        tag: "path",
                        attr: {
                            fillRule: "evenodd",
                            d: "M6.95.435c.58-.58 1.52-.58 2.1 0l6.515 6.516c.58.58.58 1.519 0 2.098L9.05 15.565c-.58.58-1.519.58-2.098 0L.435 9.05a1.482 1.482 0 010-2.098L6.95.435zm1.4.7a.495.495 0 00-.7 0L1.134 7.65a.495.495 0 000 .7l6.516 6.516a.495.495 0 00.7 0l6.516-6.516a.495.495 0 000-.7L8.35 1.134z",
                            clipRule: "evenodd"
                        }
                    }]
                })(l)
            }
        }
    }
]);