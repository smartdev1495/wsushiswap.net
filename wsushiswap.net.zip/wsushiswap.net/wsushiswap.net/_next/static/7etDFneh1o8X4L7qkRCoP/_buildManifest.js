self.__BUILD_MANIFEST = function(c, s, a) {
    return {
        __rewrites: {
            beforeFiles: [],
            afterFiles: [],
            fallback: []
        },
        "/": [c, "static/chunks/17007de1-8a78f7aad40a61d2463c.js", "static/chunks/95b64a6e-b90fe6d99ef90c8536d2.js", "static/chunks/1bfc9850-cf75a28a50f19fae74aa.js", "static/chunks/0c428ae2-d6732c48dc2b376528f9.js", "static/chunks/d7eeaac4-78e97c98a27e4b3bb3d1.js", "static/chunks/75fc9c18-42e135005113170f942a.js", "static/chunks/ea88be26-98bc06152c57ff49de85.js", s, "static/chunks/427-6194837c3f03d4c788aa.js", a, "static/chunks/pages/index-14dddc46a2f356908522.js"],
        "/_error": ["static/chunks/pages/_error-2417d1716c00bde529fc.js"],
        "/db": [c, s, a, "static/chunks/pages/db-a50082490bccfb735e0a.js"],
        sortedPages: ["/", "/_app", "/_error", "/db"]
    }
}("static/chunks/0a6e12db-f5180ed32e76975a43c9.js", "static/chunks/241-197c39d2c6895e787a32.js", "static/chunks/899-dbc5238b2fe867276510.js"), self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB();